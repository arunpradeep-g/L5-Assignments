"""Local PDF RAG application."""
