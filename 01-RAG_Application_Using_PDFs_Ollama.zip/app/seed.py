from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

ROOT = Path(__file__).resolve().parents[1]
PDFS = ROOT / "data" / "pdfs"
DOCS = {
    "rag-fundamentals.pdf": ("RAG Fundamentals", ["Retrieval-Augmented Generation combines search with a language model. Instead of relying only on a model's parameters, it retrieves relevant passages at question time and provides them as context.", "A typical pipeline extracts text, splits it into overlapping chunks, converts chunks into embeddings, stores vectors with metadata, retrieves the closest chunks, and asks a model to answer only from that evidence.", "Strong RAG answers show their sources. Page-aware citations help a reader verify a claim and reduce the chance that a plausible-looking answer is unsupported."]),
    "ollama-local-ai.pdf": ("Running Local AI with Ollama", ["Ollama runs language models locally through a simple HTTP API. A chat model can generate answers while an embedding model turns text into vectors for semantic search.", "For this application, llama3.2 produces grounded answers and nomic-embed-text creates embeddings. Both models must be pulled once, then remain available locally.", "Local execution keeps document contents on the computer. Applications should still handle untrusted PDF text carefully and instruct the model to treat retrieved content as reference material, not as commands."]),
    "evaluation-playbook.pdf": ("RAG Evaluation Playbook", ["Evaluate retrieval separately from generation. For retrieval, check whether the evidence needed to answer a question appears in the top results. For generation, judge accuracy, completeness, citation quality, and whether the answer says when evidence is missing.", "Chunk size is a trade-off. Very small chunks can lose surrounding meaning; very large chunks add distracting context. Overlap helps preserve statements that span chunk boundaries.", "A production system benefits from observability: record the retrieved chunks, similarity scores, model names, latency, and user feedback. These traces make failures diagnosable and improvements measurable."]),
}
def build(path, title, paragraphs):
    s=getSampleStyleSheet(); story=[Paragraph(title,s['Title']),Spacer(1,18)]
    for p in paragraphs: story += [Paragraph(p,s['BodyText']),Spacer(1,12)]
    SimpleDocTemplate(str(path),pagesize=letter,title=title).build(story)
def main():
    PDFS.mkdir(parents=True,exist_ok=True)
    for name,(title,paras) in DOCS.items(): build(PDFS/name,title,paras)
    print(f'Created {len(DOCS)} sample PDFs in {PDFS}')
if __name__ == '__main__': main()
