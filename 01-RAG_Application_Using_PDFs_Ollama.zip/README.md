# Portable PDF RAG

This folder is a portable local RAG app. Keep the folder together, copy it to another Windows PC, then double-click `run-portable.cmd`.

## One-time prerequisites

- Windows 10/11
- Python 3.10 or newer, available as `py`
- [Ollama](https://ollama.com/download)
- Internet access only on the first run, to install Python packages and download models

The launcher creates `.venv` inside this folder, pulls `llama3.2` and `embeddinggemma` into Ollama, opens the app, and starts the server. Later runs work offline as long as the models and Python environment remain on the machine.

## Your documents

Place PDFs in `data\pdfs\` before launch, or upload them from the app. The app creates the local index at `data\store.json`. To force a clean index, use **Clear index** in the UI and click **Reindex PDFs**.

## Configuration

Before launching, set any of these in Command Prompt if needed:

```cmd
set OLLAMA_CHAT_MODEL=llama3.2
set OLLAMA_EMBED_MODEL=embeddinggemma
set RAG_CHUNK_SIZE=900
set RAG_CHUNK_OVERLAP=150
set RAG_MAX_UPLOAD_MB=25
run-portable.cmd
```

The app never sends PDFs to a cloud service: it calls Ollama at `http://127.0.0.1:11434` only.
